Telegram Camera Site
====================

ئەم نموونەیە:
- بەکارهێنەر خۆی دەبێت Allow بۆ کامێرا بکات.
- وێنەکە لەسەر ئامێرەکە دروست دەکات.
- هیچ وێنەیەک بە نهێنی ناداتە Telegram.

بۆ ناردنی وێنە بۆ Telegram، پێویستە backend/serverێکی پارێزراو هەبێت و Bot Token لە server environment variable دابنرێت؛ Token مەخە ناو JavaScriptی browser.
